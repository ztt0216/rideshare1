# Null-Pointers — Part 1B (Wiki Home)

**Live Demo**
- Frontend: https://null-pointers-1.onrender.com/
- Backend Base: https://null-pointers-or0u.onrender.com/api
  - Health: `GET https://null-pointers-or0u.onrender.com/health`
  - Availability: `GET/POST https://null-pointers-or0u.onrender.com/api/availability`

**Start Here**
- 📄 **README (source of truth)**: https://github.com/SWEN90007-2025-sem2/Null-Pointers#readme  
  - Run & Deploy → https://github.com/SWEN90007-2025-sem2/Null-Pointers#run--deploy  
  - API → https://github.com/SWEN90007-2025-sem2/Null-Pointers#api  
  - Architecture → https://github.com/SWEN90007-2025-sem2/Null-Pointers#architecture-at-a-glance  
- ✅ **Spec Mapping**（评分对照）→ [[Spec Mapping]]
- 🧪 **Demo & Test**（自测步骤）→ [[Demo & Test]]
- 🏷 **Release & Tagging**（打标签）→ [[Release & Tagging]]

**Architecture snapshot**
```mermaid
flowchart LR
UI[React App] -->|HTTP| API[ApiServer]
API --> DAO[AvailabilityDao (JDBC)]
DAO --> DB[(PostgreSQL)]
```
> Keep this page short; details live in README.
