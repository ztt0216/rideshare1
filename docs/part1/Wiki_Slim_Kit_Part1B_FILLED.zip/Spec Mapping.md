# Spec Mapping（作业要求 ⇄ 我们的证据）

| Requirement | Where to verify | Evidence |
|---|---|---|
| UI to set driver weekly availability | [[Demo & Test]] / https://github.com/SWEN90007-2025-sem2/Null-Pointers#what-this-deliverable-covers-part1b | Live link + UI screenshot |
| Persist to DB | https://github.com/SWEN90007-2025-sem2/Null-Pointers#database-schema | `availability` schema + API GET result |
| HTTP API exists | https://github.com/SWEN90007-2025-sem2/Null-Pointers#api | `GET/POST /api/availability`, `GET /health` |
| Layered architecture | https://github.com/SWEN90007-2025-sem2/Null-Pointers#architecture-at-a-glance | diagram + package layout |
| Deploy on Render | [[Home]] / https://github.com/SWEN90007-2025-sem2/Null-Pointers#deploy-to-render | Frontend/Backend links |
| Use release tag | [[Release & Tagging]] | tag name + screenshot of releases |
