# Release & Tagging（按规范打标签）

你们还没有创建 Tag。下面提供一个**建议的 Tag 名称**（可改）：`SWEN90007_2025_Part1B_Null-Pointers`

```bash
# 建议做法（可把 SWEN90007_2025_Part1B_Null-Pointers 改为你们最终想用的名字）
git tag SWEN90007_2025_Part1B_Null-Pointers
git push origin SWEN90007_2025_Part1B_Null-Pointers
# Deploy this TAG on Render (not main)
```

> 具体部署步骤复用 README：https://github.com/SWEN90007-2025-sem2/Null-Pointers#deploy-to-render
