# Demo & Test（最小可验证）

## UI Path
1) 打开前端：https://null-pointers-1.onrender.com/
2) 选择 *Monday 09:00–17:00* → **Save** → 出现成功提示
3) 刷新页面 → 列表出现新记录

## API Quick Checks
```bash
curl -s https://null-pointers-or0u.onrender.com/api/availability | jq .
curl -s -X POST https://null-pointers-or0u.onrender.com/api/availability   -H 'Content-Type: application/json'   -d '{"driverId":1,"availableDay":"MONDAY","startTime":"09:00","endTime":"17:00"}'
```
> 详细 API 说明见 README：https://github.com/SWEN90007-2025-sem2/Null-Pointers#api
