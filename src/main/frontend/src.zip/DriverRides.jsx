// src/DriverRides.jsx
import { useEffect, useState } from "react";
import { listDriverRides, acceptRide } from "./api";

function estimateFareFromPostcodes(pickupPostcode, destinationPostcode) {
  const A = Number(String(pickupPostcode || "").replace(/\D/g, ""));
  const B = Number(String(destinationPostcode || "").replace(/\D/g, ""));
  if (A === 3045 || B === 3045) return 60;
  const isMetro = (n) => n >= 3000 && n <= 3299;
  const isRegional = (n) => n >= 3300 && n <= 3999;
  if (isRegional(A) || isRegional(B)) return 220;
  if (isMetro(A) && isMetro(B)) return 40;
  return 220;
}

export default function DriverRides() {
  const [items, setItems] = useState([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function reload() {
    setMsg(""); setLoading(true);
    try {
      const resp = await listDriverRides();
      if (resp && resp.insideWindow === false) {
        setItems([]);
        setMsg(resp.message || "You are outside your availability window.");
      } else {
        const arr = Array.isArray(resp) ? resp : (Array.isArray(resp?.items) ? resp.items : []);
        setItems(arr);
        if (arr.length === 0) setMsg("No matching ride requests at the moment.");
      }
    } catch (err) {
      setMsg(err.message || String(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { reload(); }, []);

  async function onAccept(id) {
    setMsg("");
    try {
      await acceptRide(id);             // 后端要求 { rideId }
      setMsg(`Accepted ride #${id}.`);
      await reload();
    } catch (err) {
      setMsg(err.message || String(err));
    }
  }

  return (
    <div className="page">
      <h2>Requested Rides</h2>

      <div className="list">
        {items.map((it) => (
          <div key={it.id} className="card ride">
            <div className="row space">
              <div>
                <div><b>#{it.id}</b> — {it.pickup ?? "?"} → {it.destination ?? "?"}</div>
                <div className="muted">
                  Requested: {String(it.requestedTime || "").replace("T"," ").replace("Z","")}
                  {" · Fare: "}
                  {it.fareEstimate
                    ? it.fareEstimate
                    : ("$" + estimateFareFromPostcodes(it.pickup, it.destination))}
                </div>
              </div>
              <div>
                <button onClick={() => onAccept(it.id)}>Accept</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {loading && <p className="muted">Loading…</p>}
      {msg && <p className="msg">{msg}</p>}
    </div>
  );
}
