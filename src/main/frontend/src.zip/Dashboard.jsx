import { useState } from "react";
import { authRegister, saveClientSessionUser } from "./api";

export default function Register() {
  const [name, setName] = useState("");
  const [role, setRole] = useState("RIDER");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setMsg("");
    try {
      if (!name.trim()) throw new Error("Name is required");
      const user = await authRegister({ name: name.trim(), email: email.trim(), password, role });
      saveClientSessionUser(user);
      window.location.hash = role === "DRIVER" ? "#driver" : "#rider";
    } catch (err) {
      setMsg(err.message || String(err));
    }
  }

  return (
    <div className="auth-panel">
      <h2>Create account</h2>
      <form onSubmit={onSubmit} className="form">
        <label>Name</label>
        <input placeholder="e.g. Tracy Teacher" value={name}
               onChange={(e)=>setName(e.target.value)} />
        <label>Email</label>
        <input type="email" placeholder="you@example.com" value={email}
               onChange={(e)=>setEmail(e.target.value)} />
        <label>Password</label>
        <input type="password" placeholder="Minimum 10 chars" value={password}
               onChange={(e)=>setPassword(e.target.value)} />
        <label>Role</label>
        <select value={role} onChange={(e)=>setRole(e.target.value)}>
          <option value="RIDER">Rider</option>
          <option value="DRIVER">Driver</option>
        </select>
        <button type="submit">Register</button>
        {msg && <p className="msg">{msg}</p>}
      </form>
      <div className="muted">Already have an account? <a href="#login">Sign in</a></div>
    </div>
  );
}
