// src/api.js
// Backend contract (Render):
// - POST   /api/register        -> { token?, user? } or user object
// - POST   /api/login           -> { token?, user? } or user object
// - POST   /api/logout
// - GET    /api/me              -> user
// - POST   /api/rides/request   (body: { pickup:int, destination:int, pickup_time?:int(sec) })
// - GET    /api/rides/available -> { insideWindow, message?, items:[...] } OR straight array
// - POST   /api/rides/accept    (body: { rideId })
// - GET    /api/availability?driverId=ID
// - POST   /api/availability?driverId=ID (body: { availableDay, startTime, endTime })
// - DELETE /api/availability/:slotId?driverId=ID   (if id exists)

// src/api.js
// 说明：当 VITE_USE_MOCK=1 时，所有 API 调用走内存 Mock；否则按后端接口访问。
// Mock 的数据模型：users / rides / availability，全在内存，刷新页面即清空。

const BASE = (import.meta.env.VITE_API_BASE || "/api").replace(/\/$/, "");
const USE_MOCK = String(import.meta.env.VITE_USE_MOCK || "0") === "1";

let TOKEN = sessionStorage.getItem("auth_token") || "";
function authz(h = {}) { return TOKEN ? { ...h, Authorization: `Bearer ${TOKEN}` } : h; }

async function http(path, { method = "GET", headers = {}, body } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: authz(headers),
    body,
    credentials: "include",
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || res.statusText);
  }
  if (res.status === 204) return null;
  const ct = res.headers.get("content-type") || "";
  return ct.includes("application/json") ? res.json() : res.text();
}

/* ------------------------------------------------------------------ */
/* ============================== MOCK ============================== */
/* ------------------------------------------------------------------ */
const mock = (() => {
  if (!USE_MOCK) return null;

  const db = {
    users: [
      { id: 1, name: "Jack",  email: "jack@jack.com",  password: "P@ssw0rd1234", role: "DRIVER" },
      { id: 2, name: "Tracy", email: "tracy@school.edu", password: "P@ssw0rd1234", role: "RIDER" },
    ],
    rides: [
      // { id, riderId, driverId?, status:'REQUESTED'|'ACCEPTED'|..., pickup_postcode:int, destination_postcode:int, requestedAt:ISO }
    ],
    availability: [
      // { id, driverId, availableDay:'THURSDAY', startTime:'00:00', endTime:'23:59' }
    ],
    tokens: new Map(), // token -> userId
  };
  const idc = { user: 3, ride: 1, avail: 1 };

  const delay = (ms = 250) => new Promise(r => setTimeout(r, ms));
  const nowISO = () => new Date().toISOString();
  const dayName = (d = new Date()) =>
    ["SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"][d.getDay()];

  function getUserByToken(token) {
    const uid = db.tokens.get(token);
    return db.users.find(u => u.id === uid) || null;
  }
  function minutesOf(t) { // 'HH:mm' -> minutes
    const [h, m] = String(t).split(":").map(n => parseInt(n, 10));
    return (h || 0) * 60 + (m || 0);
  }
  function insideWindowFor(driverId) {
    const today = dayName();
    const slots = db.availability.filter(a => a.driverId === driverId && (a.availableDay || "").toUpperCase() === today);
    if (slots.length === 0) return false;
    const now = new Date();
    const cur = now.getUTCHours() * 60 + now.getUTCMinutes(); // 用“统一标准的时间判断”，避免本地/服务器时区不一致
    // 我们的 mock 采用本地时间的 HH:mm 保存，判断也走本地时间（更直观）
    const curLocal = now.getHours() * 60 + now.getMinutes();
    return slots.some(s => {
      const sMin = minutesOf(s.startTime);
      const eMin = minutesOf(s.endTime);
      return sMin <= curLocal && curLocal <= eMin;
    });
  }
  function fareFrom(a, b) {
    const A = Number(a), B = Number(b);
    if (A === 3045 || B === 3045) return 60;
    const isMetro = (n) => n >= 3000 && n <= 3299;
    const isRegional = (n) => n >= 3300 && n <= 3999;
    if (isRegional(A) || isRegional(B)) return 220;
    if (isMetro(A) && isMetro(B)) return 40;
    return 220;
  }

  return {
    /* ===== Auth ===== */
    async register({ name, email, password, role }) {
      await delay();
      const existed = db.users.find(u => u.email.toLowerCase() === String(email).toLowerCase());
      if (existed) throw new Error("Email already registered");
      const user = { id: idc.user++, name, email, password, role: String(role || "").toUpperCase() || "RIDER" };
      db.users.push(user);
      const token = Math.random().toString(36).slice(2);
      db.tokens.set(token, user.id);
      return { token, user: { id: user.id, name, email, role: user.role } };
    },
    async login({ email, password }) {
      await delay();
      const u = db.users.find(x => x.email.toLowerCase() === String(email).toLowerCase() && x.password === password);
      if (!u) throw new Error("Invalid email or password");
      const token = Math.random().toString(36).slice(2);
      db.tokens.set(token, u.id);
      return { token, user: { id: u.id, name: u.name, email: u.email, role: u.role } };
    },
    async me(token) {
      await delay(120);
      const u = getUserByToken(token);
      if (!u) throw new Error("Unauthorized");
      return { id: u.id, name: u.name, email: u.email, role: u.role };
    },
    async logout(token) {
      await delay(80);
      db.tokens.delete(token);
      return { ok: true };
    },

    /* ===== Rides ===== */
    async createRide({ origin, destination /* , pickup_time(sec) 可忽略 */ }, riderId) {
      await delay();
      const ride = {
        id: idc.ride++,
        riderId,
        status: "REQUESTED",
        pickup_postcode: Number(origin),
        destination_postcode: Number(destination),
        requestedAt: nowISO(),
      };
      db.rides.push(ride);
      return {
        id: ride.id,
        pickupPostcode: ride.pickup_postcode,
        destinationPostcode: ride.destination_postcode,
        requestedAt: ride.requestedAt,
        status: ride.status,
        fare: `AUD ${fareFrom(ride.pickup_postcode, ride.destination_postcode)}`,
        riderId: ride.riderId,
        driverId: null,
        estimatedMinutes: 10,
      };
    },

    async listDriverRides(driverId) {
      await delay(180);
      const inside = insideWindowFor(driverId);
      const items = db.rides
        .filter(r => r.status === "REQUESTED")
        .map(r => ({
          id: r.id,
          pickup: `Postcode ${r.pickup_postcode}`,
          destination: `Postcode ${r.destination_postcode}`,
          requestedTime: r.requestedAt,
          fareEstimate: `AUD ${fareFrom(r.pickup_postcode, r.destination_postcode).toFixed(2)}`,
        }));
      return { insideWindow: inside, message: inside ? null : "You're currently outside your availability window.", items };
    },

    async acceptRide(rideId, driverId) {
      await delay(120);
      const r = db.rides.find(x => x.id === Number(rideId));
      if (!r) throw new Error("Ride not found");
      if (r.status !== "REQUESTED") throw new Error("Ride not available");
      r.status = "ACCEPTED";
      r.driverId = driverId;
      return { status: "ACCEPTED", rideId: r.id, ok: true };
    },

    /* ===== Availability ===== */
    async listAvailability(driverId) {
      await delay(100);
      return db.availability.filter(a => a.driverId === driverId);
    },
    async addAvailability(driverId, { dayOfWeek, start, end }) {
      await delay(120);
      const slot = {
        id: idc.avail++,
        driverId,
        availableDay: String(dayOfWeek).toUpperCase(),
        startTime: start,
        endTime: end,
      };
      db.availability = db.availability.filter(a => !(a.driverId === driverId && a.availableDay === slot.availableDay));
      db.availability.push(slot);
      return { ok: true };
    },
    async deleteAvailability(driverId, slotId) {
      await delay(80);
      db.availability = db.availability.filter(a => !(a.driverId === driverId && a.id === Number(slotId)));
      return { ok: true };
    },
  };
})();

/* ------------------------------------------------------------------ */
/* ============================ PUBLIC API ========================== */
/* ------------------------------------------------------------------ */

function meLocal() {
  try { return JSON.parse(sessionStorage.getItem("session_user") || "{}"); }
  catch { return {}; }
}

/* ===== Auth ===== */
export async function authRegister({ name, email, password, role }) {
  if (USE_MOCK) {
    const j = await mock.register({ name, email, password, role });
    const token = j.token || "";
    if (token) { TOKEN = token; sessionStorage.setItem("auth_token", token); }
    const user = j.user;
    sessionStorage.setItem("session_user", JSON.stringify(user));
    return user;
  }
  const r = await fetch(`${BASE}/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password, role }),
    credentials: "include",
  });
  if (!r.ok) throw new Error(await r.text());
  let j = {}; try { j = await r.json(); } catch {}
  const token = j.token || j.accessToken || j.jwt || "";
  if (token) { TOKEN = token; sessionStorage.setItem("auth_token", token); }
  const user = j.user || { name, email, role };
  if (user.role) user.role = String(user.role).toUpperCase();
  sessionStorage.setItem("session_user", JSON.stringify(user));
  return user;
}

export async function authLogin({ email, password }) {
  if (USE_MOCK) {
    const j = await mock.login({ email, password });
    const token = j.token || "";
    if (token) { TOKEN = token; sessionStorage.setItem("auth_token", token); }
    const user = j.user;
    sessionStorage.setItem("session_user", JSON.stringify(user));
    return user;
  }
  const r = await fetch(`${BASE}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
    credentials: "include",
  });
  if (!r.ok) throw new Error(await r.text());
  let j = {}; try { j = await r.json(); } catch {}
  const token = j.token || j.accessToken || j.jwt || "";
  if (token) { TOKEN = token; sessionStorage.setItem("auth_token", token); }
  let user = j.user || (j.id || j.role || j.email ? j : null);
  if (!user) { try { user = await http("/me"); } catch {} }
  if (!user) throw new Error("Login succeeded but no user payload.");
  if (user.role) user.role = String(user.role).toUpperCase();
  sessionStorage.setItem("session_user", JSON.stringify(user));
  return user;
}

export async function authLogout() {
  if (USE_MOCK) {
    try { await mock.logout(TOKEN); } finally {
      TOKEN = "";
      sessionStorage.removeItem("auth_token");
      sessionStorage.removeItem("session_user");
    }
    return;
  }
  try { await http("/logout", { method: "POST" }); }
  finally {
    TOKEN = "";
    sessionStorage.removeItem("auth_token");
    sessionStorage.removeItem("session_user");
  }
}

export async function getSessionUser() {
  const cached = sessionStorage.getItem("session_user");
  if (cached) return JSON.parse(cached);
  if (USE_MOCK) throw new Error("No session");
  const u = await http("/me");
  sessionStorage.setItem("session_user", JSON.stringify(u));
  return u;
}

/* ===== Rides ===== */
export async function createRide({ origin, destination, pickup_time }) {
  if (USE_MOCK) {
    const u = meLocal();
    if (!u?.id) throw new Error("Please sign in as rider");
    return mock.createRide({ origin, destination, pickup_time }, u.id);
  }
  const body = {
    pickup: Number(origin),
    destination: Number(destination),
    ...(pickup_time ? { pickup_time: Math.floor(new Date(pickup_time).getTime() / 1000) } : {}),
  };
  return http("/rides/request", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function listDriverRides() {
  if (USE_MOCK) {
    const u = meLocal();
    if (!u?.id) throw new Error("Please sign in as driver");
    return mock.listDriverRides(u.id);
  }
  return http("/rides/available");
}

export async function acceptRide(rideId) {
  if (USE_MOCK) {
    const u = meLocal();
    if (!u?.id) throw new Error("Please sign in as driver");
    return mock.acceptRide(rideId, u.id);
  }
  return http("/rides/accept", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ rideId }),
  });
}

/* ===== Availability ===== */
export async function listAvailability() {
  const u = meLocal();
  if (!u?.id) throw new Error("Please sign in as driver");
  if (USE_MOCK) return mock.listAvailability(u.id);

  const r = await http(`/availability?driverId=${encodeURIComponent(u.id)}`);
  if (Array.isArray(r)) return r;
  if (r && Array.isArray(r.value)) return r.value;
  return [];
}

export async function addAvailability({ dayOfWeek, start, end }) {
  const u = meLocal();
  if (!u?.id) throw new Error("Please sign in as driver");
  if (USE_MOCK) return mock.addAvailability(u.id, { dayOfWeek, start, end });

  const body = { availableDay: dayOfWeek, startTime: start, endTime: end };
  return http(`/availability?driverId=${encodeURIComponent(u.id)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function deleteAvailability(slotId) {
  const u = meLocal();
  if (!u?.id) throw new Error("Please sign in as driver");
  if (USE_MOCK) return mock.deleteAvailability(u.id, slotId);

  if (slotId == null) throw new Error("This slot has no id on server; removal is not supported.");
  let r = await fetch(`${BASE}/availability/${slotId}?driverId=${u.id}`, {
    method: "DELETE",
    headers: authz(),
    credentials: "include",
  });
  if (r.status === 404) {
    r = await fetch(`${BASE}/availability?driverId=${u.id}&id=${slotId}`, {
      method: "DELETE",
      headers: authz(),
      credentials: "include",
    });
  }
  if (!r.ok) throw new Error(await r.text());
  return null;
}

/* ===== Session helper ===== */
export function saveClientSessionUser(u) {
  sessionStorage.setItem("session_user", JSON.stringify(u));
}
export function clearClientSessionUser() {
  sessionStorage.removeItem("session_user");
}
