import { useState } from "react";
import { createRide } from "./api";

function isPostcode(x){ return /^\d{4}$/.test(String(x).trim()); }
function calcFare(a,b){
  const A=String(a).trim(), B=String(b).trim();
  if (A==="3045"||B==="3045") return 60;
  const not3xxx=(x)=>!/^3\d{3}$/.test(x);
  if (not3xxx(A)||not3xxx(B)) return 500;
  const nA=+A, nB=+B, isMetro=(n)=>n>=3000&&n<=3299, isRegional=(n)=>n>=3300&&n<=3999;
  if (isRegional(nA)||isRegional(nB)) return 220;
  if (isMetro(nA)&&isMetro(nB)) return 40;
  return 220;
}

export default function RiderRequest(){
  const [origin,setOrigin]=useState("");
  const [dest,setDest]=useState("");
  const [pickup,setPickup]=useState("");
  const [fare,setFare]=useState(null);
  const [stage,setStage]=useState("input");
  const [msg,setMsg]=useState("");
  const [loading,setLoading]=useState(false);

  function onPreview(e){
    e.preventDefault(); setMsg("");
    if(!isPostcode(origin)||!isPostcode(dest)){ setMsg("Please enter two valid 4-digit postcodes."); return; }
    if(!pickup){ setMsg("Please choose a pickup time."); return; }
    setFare(calcFare(origin,dest)); setStage("confirm");
  }

  async function onConfirm(){
    setMsg(""); setLoading(true);
    try{
      const iso = pickup.length===16 ? pickup+":00" : pickup;
      const r = await createRide({ origin, destination: dest, pickup_time: iso });
      setMsg(`Ride created #${r?.id ?? "?"}.`);
      setStage("input"); setFare(null); setOrigin(""); setDest(""); setPickup("");
    }catch(err){ setMsg(err.message || String(err)); }
    finally{ setLoading(false); }
  }

  return (
    <div className="page">
      <h2>Request a Ride</h2>
      {stage==="input" && (
        <form onSubmit={onPreview} className="card">
          <label>Pickup Postcode</label>
          <input value={origin} onChange={e=>setOrigin(e.target.value)} placeholder="e.g. 3000" />
          <label>Destination Postcode</label>
          <input value={dest} onChange={e=>setDest(e.target.value)} placeholder="e.g. 3045" />
          <label>Pickup Time</label>
          <input type="datetime-local" value={pickup} onChange={e=>setPickup(e.target.value)} />
          <button type="submit">Preview Fare</button>
          {msg && <p className="msg">{msg}</p>}
        </form>
      )}
      {stage==="confirm" && (
        <div className="card">
          <h3>Confirm Ride</h3>
          <p>{origin} → {dest} &nbsp;|&nbsp; Pickup: {pickup.replace("T"," ")}</p>
          <p><b>Fare: ${fare}</b></p>
          <div className="row">
            <button onClick={onConfirm} disabled={loading}>{loading?"Creating…":"Confirm"}</button>
            <button className="ghost" onClick={()=>setStage("input")} disabled={loading}>Cancel</button>
          </div>
          {msg && <p className="msg">{msg}</p>}
        </div>
      )}
    </div>
  );
}
