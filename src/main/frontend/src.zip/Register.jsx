import { useState } from "react";
import { authRegister } from "./api";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("RIDER");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setMsg(""); setLoading(true);
    try {
      const u = await authRegister({ name, email, password, role });
      // 成功：落盘并跳
      const r = String(u.role || "").toUpperCase();
      window.location.hash = r === "DRIVER" ? "#driver" : "#rider";
    } catch (err) {
      setMsg(err?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page two-col">
      <div className="card column gap">
        <h2>Create account</h2>
        <form onSubmit={onSubmit} className="column gap">
          <label>
            <div>Name</div>
            <input value={name} onChange={(e)=>setName(e.target.value)} placeholder="e.g. Tracy Teacher" required />
          </label>
          <label>
            <div>Email</div>
            <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="you@example.com" required />
          </label>
          <label>
            <div>Password</div>
            <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} minLength={10} placeholder="Minimum 10 chars" required />
          </label>
          <label>
            <div>Role</div>
            <select value={role} onChange={(e)=>setRole(e.target.value)}>
              <option value="RIDER">Rider</option>
              <option value="DRIVER">Driver</option>
            </select>
          </label>

          <button type="submit" disabled={loading}>{loading ? "Registering..." : "Register"}</button>
          {msg && <p className="msg">{msg}</p>}
        </form>

        <p style={{marginTop:16}}>
          Already have an account? <a href="#login">Sign in</a>
        </p>
      </div>

      {/* 右侧 hero：只展示，不拦截点击 */}
      <div className="hero no-pointer">
        <img src="/images/ride-hero.jpg" alt="Rideshare illustration" />
      </div>
    </div>
  );
}
