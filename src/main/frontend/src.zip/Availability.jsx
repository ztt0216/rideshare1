// src/Availability.jsx
import { useEffect, useState } from "react";
import { listAvailability, addAvailability, deleteAvailability } from "./api";

const DAYS = ["SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"];

export default function Availability() {
  const [items, setItems] = useState([]);
  const [day, setDay] = useState(DAYS[new Date().getDay()]);
  const [start, setStart] = useState("00:00");
  const [end, setEnd] = useState("23:59");
  const [msg, setMsg] = useState("");

  async function reload() {
    setMsg("");
    try {
      const data = await listAvailability(); // 可能是 [{availableDay,startTime,endTime,id?}, ...]
      setItems(Array.isArray(data) ? data : []);
    } catch (err) {
      setMsg(err.message || String(err));
    }
  }

  useEffect(() => { reload(); }, []);

  function overlaps(a, b) {
    const dayA = a.availableDay || a.dayOfWeek;
    const sA = (a.startTime || a.start || "").slice(0,5);
    const eA = (a.endTime || a.end || "").slice(0,5);
    const sB = b.start, eB = b.end;
    return dayA === b.dayOfWeek && !(eA <= sB || eB <= sA);
  }

  async function onAdd(e) {
    e.preventDefault();
    setMsg("");
    const slot = { dayOfWeek: day, start, end };
    if (start >= end) { setMsg("End time must be after start time."); return; }
    if (items.some((it) => overlaps(it, slot))) {
      setMsg("Time window overlaps an existing slot."); return;
    }
    try {
      await addAvailability(slot); // camelCase body: { availableDay, startTime, endTime }
      setMsg("Saved.");
      await reload();
    } catch (err) { setMsg(err.message || String(err)); }
  }

  async function onDelete(id) {
    setMsg("");
    try {
      await deleteAvailability(id);
      await reload();
    } catch (err) { setMsg(err.message || String(err)); }
  }

  return (
    <div className="page">
      <h2>My Weekly Availability</h2>

      <form onSubmit={onAdd} className="row wrap gap card">
        <div>
          <label>Day</label>
          <select value={day} onChange={(e)=>setDay(e.target.value)}>
            {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label>Start</label>
          <input type="time" value={start} onChange={(e)=>setStart(e.target.value)} />
        </div>
        <div>
          <label>End</label>
          <input type="time" value={end} onChange={(e)=>setEnd(e.target.value)} />
        </div>
        <button type="submit">Add Slot</button>
      </form>

      <div className="list">
        {items.map((it, idx) => {
          const id = it.id ?? null;
          const day = it.availableDay || it.dayOfWeek;
          const s = (it.startTime || it.start || "").slice(0,5);
          const e = (it.endTime || it.end || "").slice(0,5);
          return (
            <div key={id ?? `row-${idx}`} className="card row space">
              <div><b>{day}</b> &nbsp; {s}–{e}</div>
              {id != null
                ? <button className="ghost" onClick={()=>onDelete(id)}>Remove</button>
                : <button className="ghost" disabled title="This slot has no server id">Remove</button>}
            </div>
          );
        })}
      </div>

      {msg && <p className="msg">{msg}</p>}
    </div>
  );
}
