import { useEffect, useSyncExternalStore } from "react";
import Login from "./Login.jsx";
import Register from "./Register.jsx";
import Dashboard from "./Dashboard.jsx";

function subscribe(onChange) {
  window.addEventListener("hashchange", onChange);
  return () => window.removeEventListener("hashchange", onChange);
}
const getSnapshot = () => window.location.hash || "#login";
const getServerSnapshot = () => "#login";

function goByRole(user) {
  const role = String(user?.role || "").toUpperCase();
  const target = role === "DRIVER" ? "#driver" : "#rider";
  if (window.location.hash !== target) window.location.hash = target;
}

function getSessionUser() {
  try { return JSON.parse(sessionStorage.getItem("session_user") || "null"); }
  catch { return null; }
}

export default function App() {
  const route = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  // 初次无 hash 时落到 #login
  useEffect(() => { if (!window.location.hash) window.location.hash = "#login"; }, []);

  // 已登录时不允许停在 login/register
  useEffect(() => {
    const u = getSessionUser();
    if (u && (route === "#login" || route === "#register" || route === "")) goByRole(u);
  }, [route]);

  if (route === "#register") return <Register />;
  if (route === "#login") return <Login />;
  return <Dashboard />;
}

