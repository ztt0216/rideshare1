import { useState } from "react";
import { authLogin } from "./api";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setMsg("");
    setLoading(true);
    try {
      const u = await authLogin({ email, password });
      if (remember) {
        // 仅示例：保留邮箱
        localStorage.setItem("last_email", email);
      }
      const r = String(u.role || "").toUpperCase();
      window.location.hash = r === "DRIVER" ? "#driver" : "#rider";
    } catch (err) {
      setMsg(err?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page two-col">
      <div className="card column gap">
        <h2>Sign in</h2>
        <form onSubmit={onSubmit} className="column gap">
          <label>
            <div>Email</div>
            <input
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              required
            />
          </label>
          <label>
            <div>Password</div>
            <input
              type="password"
              placeholder="Your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          <label className="row gap small">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            <span>Remember me</span>
          </label>

          <button type="submit" disabled={loading}>
            {loading ? "Signing in..." : "Sign in"}
          </button>
          {msg && <p className="msg">{msg}</p>}
        </form>

        <p style={{ marginTop: 16 }}>
          No account yet? <a href="#register">Create account</a>
        </p>
      </div>

      {/* 右侧 hero（仅登录页显示） */}
      <div className="hero">
        <img src="/images/ride-hero.jpg" alt="Rideshare illustration" />
      </div>
    </div>
  );
}
